<?php
$name = $_POST['f_name'];
$age = $_POST['l_name'];
$country = $_POST['country'];
$feedback = $_POST['feedback'];


//database connection
$conn= new mysqli('localhost','root','','sahayog_db');
if($conn->connect_error)
{
   die('Connection Failed: '.$conn->connect_error);
}
else
{
   $stmt= $conn->prepare("insert into contact(f_name, l_name, country, feedback) values(?, ?, ?, ?)");
   $stmt->bind_param("ssss", $f_name, $l_name, $country, $feedback); // updated here
   $stmt->execute();
   echo "registration successful.......";
   $stmt->close();
   $conn->close();
}
?>
